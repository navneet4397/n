const assert = require('assert')
const chai = require('chai');
const expect = chai.expect;
const main = require('../js/index.js')
const { JSDOM } = require('jsdom');

describe('taskrobo', () => {
    var display;
    before(() => {
        const { document } = (new JSDOM(`<div align="center">
                                             <h4>New Category</h4>
                                             <form:form action="/taskrobo-hibernate-module/addCategory" method="post" modelAttribute="category">
                                                 <table border="0" cellpadding="5">
                                                     <tr>
                                                         <td>Category Title: </td>
                                                         <td>
                                                             <form:input path="categoryTitle" id="categoryTitle" onmouseover="validateCategoryTitle();"/>
                                                             <p id="taskTitleMsg"></p>
                                                         </td>
                                                     </tr>

                                                     <tr>
                                                         <td colspan="2"><input type="submit" value="Add Category"></td>
                                                     </tr>
                                                 </table>
                                             </form:form>
                                         </div>
                                         <section class="categories">
                                                 <div class="container-fluid mt-4">

                                                     <table class="table table-dark">
                                                         <thead>
                                                             <tr>
                                                                 <th scope="col">Category Title</th>
                                                             </tr>
                                                         </thead>
                                                         <tbody>
                                                                 <tr>
                                                                     <td><button onclick="displayAddTask();">Add Task</button></td>
                                                                 </tr>


                                                         </tbody>
                                                     </table>

                                                     <div align="center" id="addTaskDiv" style="display:none;">
                                                         <form:form action="/taskrobo-hibernate-module/addTask" method="post" modelAttribute="task">
                                                             <table border="0" cellpadding="5">
                                                             <h3>New Task</h3>
                                                                 <tr>
                                                                     <td>Task Id: </td>
                                                                     <td>
                                                                         <form:input path="taskId" id="taskId" onmouseout="validId();" />
                                                                         <p id="idMsg"></p>
                                                                     </td>
                                                                 </tr>
                                                                 <tr>
                                                                     <td>Task Title: </td>
                                                                     <td>
                                                                         <form:input path="taskTitle" id="taskTitle" onmouseout="validTitle();" />
                                                                         <p id="titleMsg"></p>
                                                                     </td>
                                                                 </tr>
                                                                 <tr>
                                                                     <td>Task Content: </td>
                                                                     <td>
                                                                         <form:input path="taskContent" id="taskContent" onmouseout="validateContent();" />
                                                                         <p id="contentMsg"></p>
                                                                     </td>
                                                                 </tr>
                                                                 <tr>
                                                                     <td>Task Status: </td>
                                                                     <td>
                                                                         <form:input path="taskStatus" id="taskStatus" onmouseover="validateStatus();" />
                                                                         <p id="statusMsg"></p>
                                                                     </td>
                                                                 </tr>
                                                                 <tr>
                                                                     <td>Category: </td>

                                                                 </tr>
                                                                 <tr>
                                                                     <td colspan="2"><input type="submit" value="Add Task"></td>
                                                                 </tr>
                                                             </table>
                                                         </form:form>
                                                     </div>
                                                 </div>
                                         </section> `)).window;
        global.document = document;
        global.window = document.defaultView;
    })

    it('updates the display type when given valid id"', () => {
        document.getElementById("taskId").value = 10;
        main.validId();
        expect(document.getElementById("idMsg").style.display).to.equal("none");
    });

    it('updates the innerHTML,color and display type when given invalid id"', () => {
        document.getElementById("taskId").value = 0;
        main.validId();
        expect(document.getElementById("idMsg").innerHTML).to.equal("Task Id is Invalid");
        expect(document.getElementById("idMsg").style.color).to.equal("red");
        expect(document.getElementById("idMsg").style.display).to.equal("block");
    });

    it('updates the innerHTML,color and display type when given string id"', () => {
        document.getElementById("taskId").value = "abc";
        main.validId();
        expect(document.getElementById("idMsg").innerHTML).to.equal("Task Id is Invalid");
        expect(document.getElementById("idMsg").style.color).to.equal("red");
        expect(document.getElementById("idMsg").style.display).to.equal("block");
    });

    it('updates the display type when given valid title"', function () {
        document.getElementById("taskTitle").value = "task10";
        main.validTitle();
        expect(document.getElementById("titleMsg").style.display).to.equal("none");
    });

    it('updates the innerHTML,color and display type when given empty title"', function () {
        document.getElementById("taskTitle").value = "";
        main.validTitle();
        expect(document.getElementById("titleMsg").innerHTML).to.equal("Task title is invalid");
        expect(document.getElementById("titleMsg").style.color).to.equal("red");
        expect(document.getElementById("titleMsg").style.display).to.equal("block");
    });

    it('updates the innerHTML,color and display type when given invalid title"', function () {
        document.getElementById("taskTitle").value = "*&task";
        main.validTitle();
        expect(document.getElementById("titleMsg").innerHTML).to.equal("Task title is invalid");
        expect(document.getElementById("titleMsg").style.color).to.equal("red");
        expect(document.getElementById("titleMsg").style.display).to.equal("block");
    });

    it('creates validator object and returns message', function () {
        validator = new main.Validator("red");
        expect(validator.getMessage()).to.equal("Task Id is Invalid")
    });

    it('creates validator object and returns null', function () {
        validator = new main.Validator("green");
        expect(validator.getMessage()).to.equal(null)
    });

    it('creates TitleValidator object and returns message', function () {
        titleValidator = new main.TitleValidator("red");
        expect(titleValidator.getMessage()).to.equal("Task title is invalid")
    });
    it('updates the display type when given valid task content"', function () {
        document.getElementById("taskContent").value = "This task is regarding creating a spring mvc application";
        main.validateContent();
        expect(document.getElementById("contentMsg").style.display).to.equal("none");
    });
    it('updates the innerHTML,color and display type when given empty content"', function () {
        document.getElementById("taskContent").value = "";
        main.validateContent();
        expect(document.getElementById("contentMsg").innerHTML).to.equal("Task content is invalid");
        expect(document.getElementById("contentMsg").style.color).to.equal("red");
        expect(document.getElementById("contentMsg").style.display).to.equal("block");
    });
    it('updates the innerHTML,color and display type when given task content with length more than 100 characters"', function () {
        document.getElementById("taskContent").value = "This task is regarding creating a spring mvc application and testing all the functionalities and implement frontend using html and css";
        main.validateContent();
        expect(document.getElementById("contentMsg").innerHTML).to.equal("Task content is invalid");
        expect(document.getElementById("contentMsg").style.color).to.equal("red");
        expect(document.getElementById("contentMsg").style.display).to.equal("block");
    });
    it('updates the display type when given valid task content"', function () {
        document.getElementById("taskContent").value = "This task is regarding creating a spring mvc application";
        main.validateContent();
        expect(document.getElementById("contentMsg").style.display).to.equal("none");
    });
    it('updates the innerHTML,color and display type when given empty content"', function () {
        document.getElementById("taskContent").value = "";
        main.validateContent();
        expect(document.getElementById("contentMsg").innerHTML).to.equal("Task content is invalid");
        expect(document.getElementById("contentMsg").style.color).to.equal("red");
        expect(document.getElementById("contentMsg").style.display).to.equal("block");
    });
    it('updates the innerHTML,color and display type when given task content with length more than 100 characters"', function () {
        document.getElementById("taskContent").value = "This task is regarding creating a spring mvc application and testing all the functionalities and implement frontend using html and css";
        main.validateContent();
        expect(document.getElementById("contentMsg").innerHTML).to.equal("Task content is invalid");
        expect(document.getElementById("contentMsg").style.color).to.equal("red");
        expect(document.getElementById("contentMsg").style.display).to.equal("block");
    });

    it('updates the display type when given valid task status"', function () {
        document.getElementById("taskStatus").value = "WIP";
        main.validateStatus();
        expect(document.getElementById("statusMsg").style.display).to.equal("none");
    });
    it('updates the innerHTML,color and display type when given empty status"', function () {
        document.getElementById("taskStatus").value = "";
        main.validateStatus();
        expect(document.getElementById("statusMsg").innerHTML).to.equal("Task status is invalid");
        expect(document.getElementById("statusMsg").style.color).to.equal("red");
        expect(document.getElementById("statusMsg").style.display).to.equal("block");
    });
    it('updates the innerHTML,color and display type when given task status with length more than 10 characters"', function () {
        document.getElementById("taskStatus").value = "Not yet completed";
        main.validateStatus();
        expect(document.getElementById("statusMsg").innerHTML).to.equal("Task status is invalid");
        expect(document.getElementById("statusMsg").style.color).to.equal("red");
        expect(document.getElementById("statusMsg").style.display).to.equal("block");
    });
    it('updates the display type when given valid Category Title"', function () {
        document.getElementById("categoryTitle").value = "Implementing Spring MVC using hibernate";
        main.validateCategoryTitle();
        expect(document.getElementById("taskTitleMsg").style.display).to.equal("none");
    });
    it('updates the innerHTML,color and display type when given empty Category Title"', function () {
        document.getElementById("categoryTitle").value = "";
        main.validateCategoryTitle();
        expect(document.getElementById("taskTitleMsg").innerHTML).to.equal("Category Title is invalid");
        expect(document.getElementById("taskTitleMsg").style.color).to.equal("red");
        expect(document.getElementById("taskTitleMsg").style.display).to.equal("block");
    });
    it('updates the innerHTML,color and display type when given Category Title with length more than 100 characters"', function () {
        document.getElementById("categoryTitle").value = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in";
        main.validateCategoryTitle();
        expect(document.getElementById("taskTitleMsg").innerHTML).to.equal("Category Title is invalid");
        expect(document.getElementById("taskTitleMsg").style.color).to.equal("red");
        expect(document.getElementById("taskTitleMsg").style.display).to.equal("block");
    });

    it('On clicking Add Task Button addTaskDiv is displayed', function () {
        document.getElementById("addTaskDiv").style.display = "none";
        main.displayAddTask();
        expect(document.getElementById("addTaskDiv").style.display).to.equal("block");
    });
    it('if addTaskDiv is displayed, on clicking "Add Task" the display is is set to "none"', function () {
        document.getElementById("addTaskDiv").style.display = "block";
        main.displayAddTask();
        expect(document.getElementById("addTaskDiv").style.display).to.equal("none");
    });




});