package com.stackroute.taskrobo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/*
 * The class "Task" will be acting as the data model for the Task Table in the database.
 * Please note that this class is annotated with @Entity annotation.
 */
@Entity
public class Task {

	/* TaskId is annotated with @Id */
	@Id
	private int taskId;
	private String taskTitle;
	private String taskContent;
	private String taskStatus;

	/* Category is annotated with @ManyToOne */
	@ManyToOne
	private Category category;

	public Task() {
	}

	/* Write parameterized constructor */
	public Task(int taskId, String taskTitle, String taskContent, String taskStatus, Category category) {
		super();
		this.taskId = taskId;
		this.taskTitle = taskTitle;
		this.taskContent = taskContent;
		this.taskStatus = taskStatus;
		this.category = category;
	}

	/* Add getter and setter methods for all the properties */
	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getTaskTitle() {
		return taskTitle;
	}

	public void setTaskTitle(String taskTitle) {
		this.taskTitle = taskTitle;
	}

	public String getTaskContent() {
		return taskContent;
	}

	public void setTaskContent(String taskContent) {
		this.taskContent = taskContent;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	/* Override toString() method to display the task object */
	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", taskTitle=" + taskTitle + ", taskContent=" + taskContent + ", taskStatus="
				+ taskStatus + ", category=" + category + "]";
	}

}
