package com.stackroute.taskrobo.config;

import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

import javax.sql.DataSource;
import java.io.IOException;

/*This class will contain the application-context for the application.
 * Define the following annotations:
 * @Configuration - Annotating a class with the @Configuration indicates that the
 *                  class can be used by the Spring IoC container as a source of
 *                  bean definitions
 * @EnableTransactionManagement - Enables Spring's annotation-driven transaction management capability.
 *
 * */
@Configuration
public class SpringRootConfig {
    /*
     *Define the bean for datasource.
     */

    public DataSource getDataSource() {
        return null;
    }

    /*
     * Define the bean for SessionFactory. Hibernate SessionFactory is the factory
     * class through which we get sessions and perform database operations.
     */


    public LocalSessionFactoryBean getSessionFactory(DataSource dataSource) throws IOException {
        return null;
    }

    /*
     * Define the bean for Transaction Manager. HibernateTransactionManager handles
     * transaction in Spring. The application that uses single hibernate session
     * factory for database transaction has good choice to use
     * HibernateTransactionManager. HibernateTransactionManager can work with plain
     * JDBC too. HibernateTransactionManager allows bulk update and bulk insert and
     * ensures data integrity.
     */
    public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory) {
        return null;
    }
}