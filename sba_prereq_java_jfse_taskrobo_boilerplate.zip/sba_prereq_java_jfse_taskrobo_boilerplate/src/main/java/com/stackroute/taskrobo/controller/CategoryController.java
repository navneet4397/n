package com.stackroute.taskrobo.controller;

import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.service.CategoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/*
 * Annotate the class with @Controller annotation. @Controller annotation is used to mark
 * any POJO class as a controller so that Spring can recognize this class as a Controller
 */
@Controller
@RequestMapping("/")
@PropertySource("classpath:application.properties")
public class CategoryController {
	/*
	 * From the problem statement, we can understand that the application requires
	 * us to implement the following functionalities.
	 *
	 * 1. display the list of existing Categories from the persistence data. Each
	 * Category element should contain CategoryTitle 2. Add a new category which
	 * should contain the Title 3.Delete an existing Category 4.Get All Tasks
	 * associated with particular category
	 *
	 */

	/*
	 * Constructor based Autowiring should be implemented for the CategoryService
	 * and Environment.Please note that we should not create any object using the
	 * new keyword.
	 */
	private CategoryService categoryService;
	private Environment environment;

	@Autowired
	public CategoryController(CategoryService categoryService, Environment environment) {
		super();
		this.categoryService = categoryService;
		this.environment = environment;
	}

	/*
	 * Define a handler method to fetch all categories. Also add category and task
	 * instances to model attribute. This handler method should map to the URL "/".
	 * If the operation success then return to index.
	 */
	@GetMapping(value = "/")
	public String indexPage(ModelMap model) {

		return categoryService.getAllCategories();
	}

	/*
	 * Define a handler method to add new category. This handler method should map
	 * to the URL "/addCategory". If the title is empty, return to index. If the
	 * operation success then redirect to "/".Show the errorMessage in case of any
	 * exception and return to "index"
	 */
	@PostMapping(value = "/addCategory")
	public String saveCategory(@ModelAttribute("category") Category category, ModelMap model) {
		return null;
	}

	/*
	 * Define a handler method to delete existing category. This handler method
	 * should map to the URL "/deleteCategory". If the operation success then
	 * redirect to "/". Show the errorMessage in case of any exception and return to
	 * index
	 */

	@GetMapping("/deleteCategory")
	public String deleteCategory(@RequestParam("categoryTitle") String categoryTitle, ModelMap model) {
		return null;
	}
	/*
	 * Define a handler method to fetch all tasks of particular category. This
	 * handler method should map to the URL "/getTasks". If the operation success
	 * then redirect to index. Show the errorMessage in case of any exception and
	 * return to index.
	 */

	@GetMapping("/getTasks")
	public String getAllTasks(@RequestParam("categoryTitle") String categoryTitle, ModelMap model) {
		return null;
	}

}
