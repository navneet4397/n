package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.dao.CategoryDao;
import com.stackroute.taskrobo.exception.CategoryAlreadyExistException;
import com.stackroute.taskrobo.exception.CategoryDoesNotExistException;
import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;

/*
 * Service classes are used here to implement additional business logic/validation
 * This class has to be annotated with @Service annotation.
 */

@PropertySource("classpath:application.properties")
@Service
public class CategoryServiceImpl implements CategoryService {
	/*
	 * Constructor based Autowiring should be implemented for the CategoryDao and
	 * Environment.Please note that we should not create any object using the new
	 * keyword.
	 */

	private CategoryDao categoryDao;

	@Autowired
	public CategoryServiceImpl(CategoryDao categoryDao) {
		super();
		this.categoryDao = categoryDao;
	}

	/*
	 * Do not hardcode exception message. Get it from application.properties using
	 * environment variables.
	 */
	private Environment environment;

	@Autowired
	public CategoryServiceImpl(Environment environment) {
		super();
		this.environment = environment;
	}

	/*
	 * This method should be used to save a new category.
	 */

	@Override
	@Value("${categoryAlreadyExistException.message}")
	public boolean saveCategory(Category category) throws CategoryAlreadyExistException {
		categoryDao.saveCategory(category);
		return false;
	}

	/*
	 * This method should be used to get a category by categoryTitle.
	 */

	@Override
	@Value("${categoryDoesNotExistException.message}")
	public Category getCategoryByTitle(String categoryTitle) throws CategoryDoesNotExistException {
		return categoryDao.getCategoryByTitle(categoryTitle);

	}

	/*
	 * This method should be used to get all the tasks for particular Category.
	 */
	@Override
	@Value("${categoryDoesNotExistException.message}")
	public List<Task> getAllTasks(String categoryTitle) throws CategoryDoesNotExistException {
		return ;
	}

	/*
	 * This method should be used to get all the categories.
	 */

	@Override
	public List<Category> getAllCategories() {
		return categoryDao.getAllCategories();
	}

	/* This method should be used to delete an existing category. */

	@Override
	@Value("${categoryDoesNotExistException.message}")
	public boolean deleteCategory(String categoryTitle) throws CategoryDoesNotExistException {
		categoryDao.deleteCategory(categoryTitle);
		return false;
	}
}