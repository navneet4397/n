package com.stackroute.taskrobo.exception;

public class TaskDoesNotExistException extends Exception {
    public TaskDoesNotExistException(String message) {
        super(message);
    }
}
