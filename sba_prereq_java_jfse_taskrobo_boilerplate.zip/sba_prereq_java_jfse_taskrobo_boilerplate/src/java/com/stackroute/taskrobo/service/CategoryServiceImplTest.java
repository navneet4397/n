package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.dao.CategoryDaoImpl;
import com.stackroute.taskrobo.exception.CategoryAlreadyExistException;
import com.stackroute.taskrobo.exception.CategoryDoesNotExistException;
import com.stackroute.taskrobo.model.Category;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.test.annotation.Rollback;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class CategoryServiceImplTest {
    @Mock
    private CategoryDaoImpl categoryDao;
    @InjectMocks
    private CategoryServiceImpl categoryService;

    @Mock
    private Environment environment;

    private Category category;

    private List<Category> categories;

    @BeforeEach
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
        category = new Category("Implementing Microservice patterns");
    }

    @AfterEach
    public void tearDown() throws Exception {
        category = null;
        categories = null;
    }

    @Test
    @Rollback(true)
    public void givenValidCategoryWhenSavedThenReturnTrue() throws CategoryAlreadyExistException {
        when(categoryDao.getCategoryByTitle(anyString())).thenReturn(null);
        when(categoryDao.saveCategory(any())).thenReturn(true);
        assertTrue(categoryService.saveCategory(category));
        verify(categoryDao, times(1)).getCategoryByTitle(category.getCategoryTitle());
        verify(categoryDao, times(1)).saveCategory(any());
    }

    @Test
    @Rollback(true)
    public void givenDuplicateCategoryThenThrowException() throws CategoryAlreadyExistException {
        when(categoryDao.getCategoryByTitle(anyString())).thenReturn(category);
        assertThrows(CategoryAlreadyExistException.class, () -> categoryService.saveCategory(category));
        verify(categoryDao, times(1)).getCategoryByTitle(anyString());
        verify(categoryDao, times(0)).saveCategory(any());
    }

    @Test
    @Rollback(true)
    public void givenValidCategoryTitleThenReturnCategory() throws CategoryDoesNotExistException {
        when(categoryDao.getCategoryByTitle(anyString())).thenReturn(category);
        assertEquals(category, categoryService.getCategoryByTitle(category.getCategoryTitle()));
        verify(categoryDao, times(1)).getCategoryByTitle(anyString());
    }

    @Test
    @Rollback(true)
    public void givenInvalidCategoryTitleThenThrowException() throws CategoryDoesNotExistException {
        when(categoryDao.getCategoryByTitle(anyString())).thenReturn(null);
        assertThrows(CategoryDoesNotExistException.class, () -> categoryService.getCategoryByTitle(category.getCategoryTitle()));
        verify(categoryDao, times(1)).getCategoryByTitle(anyString());
    }

    @Test
    @Rollback(true)
    public void givenNothingThenReturnAllCategories() {

        when(categoryDao.getAllCategories()).thenReturn(categories);

        assertEquals(categories, categoryService.getAllCategories());

        verify(categoryDao, times(1)).getAllCategories();

    }

    @Test
    @Rollback(true)
    public void givenValidCategoryTitledWhenDeletedThenReturnTrue() throws CategoryDoesNotExistException {

        when(categoryDao.getCategoryByTitle(anyString())).thenReturn(category);
        when(categoryDao.deleteCategory(anyString())).thenReturn(true);
        assertTrue(categoryService.deleteCategory(category.getCategoryTitle()));

        verify(categoryDao, times(1)).getCategoryByTitle(anyString());
        verify(categoryDao, times(1)).deleteCategory(anyString());

    }

    @Test
    @Rollback(true)
    public void givenInValidCategoryTitleWhenDeletedThenThrowException() throws CategoryDoesNotExistException {

        when(categoryDao.getCategoryByTitle(anyString())).thenReturn(null);

        assertThrows(CategoryDoesNotExistException.class, () -> categoryService.deleteCategory(category.getCategoryTitle()));

        verify(categoryDao, times(1)).getCategoryByTitle(anyString());
        verify(categoryDao, times(0)).deleteCategory(anyString());

    }

}
