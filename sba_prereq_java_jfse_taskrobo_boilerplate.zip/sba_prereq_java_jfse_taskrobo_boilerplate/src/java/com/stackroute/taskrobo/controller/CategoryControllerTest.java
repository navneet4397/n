package com.stackroute.taskrobo.controller;

import com.stackroute.taskrobo.exception.CategoryAlreadyExistException;
import com.stackroute.taskrobo.exception.CategoryDoesNotExistException;
import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;
import com.stackroute.taskrobo.service.CategoryServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class CategoryControllerTest {
    private MockMvc mockMvc;

    private Category category;
    List<Task> tasks;
    private List<Category> categories = new ArrayList<>();

    @Mock
    private CategoryServiceImpl categoryService;

    @Mock
    private Environment environment;

    @InjectMocks
    CategoryController categoryController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(categoryController).build();

        category = new Category("Kubernetes Deployment");
        categories.add(category);
    }

    @AfterEach
    public void tearDown() throws Exception {
        category = null;
    }

    @Test
    public void givenValidCategoryThenRedirectSlash() throws Exception {
        when(categoryService.saveCategory(any())).thenReturn(true);
        mockMvc.perform(post("/addCategory").param("categoryTitle", category.getCategoryTitle()))
                .andExpect(redirectedUrl("/"));
    }

    @Test
    public void givenInvalidCategoryThenForwardToIndex() throws Exception {
        when(categoryService.saveCategory(any(Category.class))).thenThrow(CategoryAlreadyExistException.class);
        mockMvc.perform(post("/addCategory").param("categoryTitle", "")).andExpect(status().isOk())
                .andExpect(forwardedUrl("index"));
    }

    @Test
    public void givenValidTaskIdWhenDeletedThenRedirectToSlash() throws Exception {
        when(categoryService.deleteCategory(category.getCategoryTitle())).thenReturn(true);
        mockMvc.perform(get("/deleteCategory").param("categoryTitle", "Kubernetes Deployment")).andExpect(redirectedUrl("/"));

    }

    @Test
    public void givenInValidTaskIdWhenDeletedThenForwardToIndex() throws Exception {
        when(categoryService.deleteCategory("abc")).thenThrow(new CategoryDoesNotExistException("Category doesn't exists!Kindly check the taskId"));
        mockMvc.perform(get("/deleteCategory").param("categoryTitle", "abc")).andExpect(forwardedUrl("index"));

    }

    @Test
    public void givenValidTaskIdThenReturnTaskAndForwardToIndex() throws Exception {
        when(categoryService.getAllTasks(category.getCategoryTitle())).thenReturn(tasks);
        mockMvc.perform(get("/getTasks").param("categoryTitle", category.getCategoryTitle())).andExpect(forwardedUrl("index"));

    }

    @Test
    public void givenInvalidTaskIdThenForwardToIndex() throws Exception {
        when(categoryService.getAllTasks("")).thenThrow(new CategoryDoesNotExistException("Category doesn't exists!Kindly check the taskId"));
        mockMvc.perform(get("/getTasks").param("categoryTitle", "")).andExpect(forwardedUrl("index"));

    }
}
