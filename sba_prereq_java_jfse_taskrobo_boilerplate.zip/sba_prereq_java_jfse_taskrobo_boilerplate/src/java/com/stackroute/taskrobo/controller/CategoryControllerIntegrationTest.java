package com.stackroute.taskrobo.controller;

import com.stackroute.taskrobo.config.SpringRootConfig;
import com.stackroute.taskrobo.dao.CategoryDaoImpl;
import com.stackroute.taskrobo.exception.CategoryAlreadyExistException;
import com.stackroute.taskrobo.exception.CategoryDoesNotExistException;
import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;
import com.stackroute.taskrobo.service.CategoryService;
import com.stackroute.taskrobo.service.CategoryServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Transactional
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringRootConfig.class, CategoryController.class, CategoryDaoImpl.class, CategoryServiceImpl.class})
public class CategoryControllerIntegrationTest {
    private Category category;
    private Task task;
    private List<Task> tasks = new ArrayList<>();

    @Autowired
    private CategoryService categoryService;


    @BeforeEach
    void setUp() {
        category = new Category("Kubernetes Deployment");


    }

    @AfterEach
    public void tearDown() throws Exception {
        category = null;
    }

    @Test
    public void givenValidCategoryThenReturnTrue() throws Exception {
        assertTrue(categoryService.saveCategory(category));
        Category savedCategory = categoryService.getCategoryByTitle(category.getCategoryTitle());
        assertEquals("Kubernetes Deployment", savedCategory.getCategoryTitle());
    }

    @Test
    public void givenInvalidCategoryThenThrowException() throws Exception {
        assertTrue(categoryService.saveCategory(category));
        assertThrows(CategoryAlreadyExistException.class, () -> categoryService.saveCategory(category));
    }

    @Test
    public void givenValidCategoryTitleWhenDeletedThenReturnTrue() throws Exception {
        assertTrue(categoryService.saveCategory(category));
        assertTrue(categoryService.deleteCategory(category.getCategoryTitle()));
        List<Category> categories = categoryService.getAllCategories();
        assertTrue(categories.isEmpty());
    }

    @Test
    public void givenInValidCategoryTitleWhenDeletedThenThrowException() throws Exception {
        assertThrows(CategoryDoesNotExistException.class, () -> categoryService.deleteCategory(category.getCategoryTitle()));

    }

    @Test
    public void givenValidCategoryTitleThenReturnTask() throws Exception {
        task = new Task(200, "task10", "Reading", "WIP");
        tasks.add(task);
        category.setTasks(tasks);
        assertTrue(categoryService.saveCategory(category));
        List<Task> retrievedTasks = categoryService.getAllTasks(category.getCategoryTitle());
        assertEquals(200, retrievedTasks.get(0).getTaskId());

    }

    @Test
    public void givenInvalidCategoryTitleThenThrowException() throws Exception {
        assertThrows(CategoryDoesNotExistException.class, () -> categoryService.getAllTasks(category.getCategoryTitle()));
    }

}
