package com.stackroute.taskrobo.controller;

import com.stackroute.taskrobo.exception.TaskAlreadyExistException;
import com.stackroute.taskrobo.exception.TaskDoesNotExistException;
import com.stackroute.taskrobo.model.Task;
import com.stackroute.taskrobo.service.TaskServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class TaskControllerTest {
    private MockMvc mockMvc;

    private Task task;
    private List<Task> taskList = new ArrayList<>();

    @Mock
    private TaskServiceImpl taskService;

    @Mock
    private Environment environment;

    @InjectMocks
    private TaskController taskController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(taskController).build();

        task = new Task(200, "task10", "Reading", "WIP");
        taskList.add(task);
    }

    @AfterEach
    public void tearDown() throws Exception {
        task = null;
    }

    @Test
    public void givenValidTaskThenRedirectSlash() throws Exception {
        when(taskService.saveTask(any())).thenReturn(true);
        mockMvc.perform(post("/addTask").param("taskTitle", task.getTaskTitle()).param("taskContent", task.getTaskContent()).param("taskStatus", task.getTaskStatus()))
                .andExpect(status().isFound()).andExpect(redirectedUrl("/"));
    }

    @Test
    public void givenInvalidTaskThenForwardToIndex() throws Exception {
        when(taskService.saveTask(any(Task.class))).thenThrow(TaskAlreadyExistException.class);
        mockMvc.perform(post("/addTask").param("taskTitle", "")).andExpect(status().isOk())
                .andExpect(forwardedUrl("index"));
    }

    @Test
    public void givenValidTaskIdWhenDeletedThenRedirectToSlash() throws Exception {
        when(taskService.deleteTask(task.getTaskId())).thenReturn(true);
        mockMvc.perform(get("/deleteTask?taskId=200")).andExpect(redirectedUrl("/"));

    }

    @Test
    public void givenInValidTaskIdWhenDeletedThenForwardToIndex() throws Exception {
        when(taskService.deleteTask(10)).thenThrow(new TaskDoesNotExistException("Task doesn't exists!Kindly check the taskId"));
        mockMvc.perform(get("/deleteTask?taskId=10")).andExpect(forwardedUrl("index"));

    }

    @Test
    public void givenValidTaskIdThenReturnTaskAndRedirectToSlash() throws Exception {
        when(taskService.getTaskById(task.getTaskId())).thenReturn(task);
        mockMvc.perform(get("/getTask?taskId=200")).andExpect(redirectedUrl("/"));

    }

    @Test
    public void givenInvalidTaskIdThenForwardToIndex() throws Exception {
        when(taskService.getTaskById(10)).thenThrow(new TaskDoesNotExistException("Task doesn't exists!Kindly check the taskId"));
        mockMvc.perform(get("/getTask?taskId=10")).andExpect(forwardedUrl("index"));

    }

    @Test
    public void givenValidTaskDetailsWhenUpdatedThenRedirectSlash() throws Exception {
        when(taskService.updateTask(any(Task.class))).thenReturn(true);
        mockMvc.perform(post("/updateTask").param("taskStatus", "completed").param("taskContent", task.getTaskContent())).andExpect(redirectedUrl("/"));
    }

    @Test
    public void givenInvalidTaskDetailsWhenUpdatedThenForwardToIndex() throws Exception {
        when(taskService.updateTask(any(Task.class))).thenThrow(new TaskDoesNotExistException("Task doesn't exists!Kindly check the taskId"));
        mockMvc.perform(post("/updateTask").param("taskStatus", "")).andExpect(status().isOk())
                .andExpect(forwardedUrl("index"));
    }
}

