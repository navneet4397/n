package com.stackroute.taskrobo.controller;

import com.stackroute.taskrobo.config.SpringRootConfig;
import com.stackroute.taskrobo.dao.TaskDaoImpl;
import com.stackroute.taskrobo.exception.TaskAlreadyExistException;
import com.stackroute.taskrobo.exception.TaskDoesNotExistException;
import com.stackroute.taskrobo.model.Task;
import com.stackroute.taskrobo.service.TaskService;
import com.stackroute.taskrobo.service.TaskServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;


@Transactional
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {SpringRootConfig.class, TaskController.class, TaskDaoImpl.class, TaskServiceImpl.class})
public class TaskControllerIntegrationTest {

    private Task task;

    @Autowired
    private TaskService taskService;


    @BeforeEach
    void setUp() {
        task = new Task(200, "task10", "Reading", "WIP");
    }

    @AfterEach
    public void tearDown() throws Exception {
        task = null;
    }

    @Test
    public void givenValidTaskThenReturnTrue() throws Exception {
        assertTrue(taskService.saveTask(task));
        Task savedTask = taskService.getTaskById(task.getTaskId());
        assertEquals(200, savedTask.getTaskId());
    }

    @Test
    public void givenInvalidTaskThenThrowException() throws Exception {
        assertTrue(taskService.saveTask(task));
        assertThrows(TaskAlreadyExistException.class, () -> taskService.saveTask(task));
    }

    @Test
    public void givenValidTaskIdWhenDeletedThenReturnTrue() throws Exception {
        assertTrue(taskService.saveTask(task));
        assertTrue(taskService.deleteTask(task.getTaskId()));
        List<Task> tasks = taskService.getAllTasks();
        assertTrue(tasks.isEmpty());
    }

    @Test
    public void givenInValidTaskIdWhenDeletedThenThrowException() throws Exception {
        assertThrows(TaskDoesNotExistException.class, () -> taskService.deleteTask(task.getTaskId()));

    }

    @Test
    public void givenValidTaskIdThenReturnTask() throws Exception {
        assertTrue(taskService.saveTask(task));
        Task retrievedTask = taskService.getTaskById(task.getTaskId());
        assertEquals(200, retrievedTask.getTaskId());

    }

    @Test
    public void givenInvalidTaskIdThenThrowException() throws Exception {
        assertThrows(TaskDoesNotExistException.class, () -> taskService.getTaskById(task.getTaskId()));
    }

    @Test
    public void givenValidTaskDetailsWhenUpdatedReturnTrue() throws Exception {
        assertTrue(taskService.saveTask(task));
        Task retrievedTask = taskService.getTaskById(this.task.getTaskId());
        retrievedTask.setTaskStatus("Completed");
        assertTrue(taskService.updateTask(retrievedTask));
        Task updatedTask = taskService.getTaskById(retrievedTask.getTaskId());
        assertEquals("Completed", updatedTask.getTaskStatus());

    }

    @Test
    public void givenInvalidTaskDetailsWhenUpdatedForwardToIndex() throws Exception {
        assertThrows(TaskDoesNotExistException.class, () -> taskService.updateTask(task));
    }

}
